-- C2-09 Meridian Commerce & Services - optional PostgreSQL-style schema
-- The CSV/JSON files are authoritative synthetic source evidence for the capstone.
CREATE TABLE customers (
  customer_id text PRIMARY KEY,
  customer_name text NOT NULL,
  region text NOT NULL,
  segment text NOT NULL,
  acquisition_channel text NOT NULL,
  start_date date NOT NULL
);
CREATE TABLE products (
  product_id text PRIMARY KEY,
  product_name text NOT NULL,
  category text NOT NULL,
  list_price numeric(12,2) NOT NULL,
  standard_unit_cost numeric(12,2) NOT NULL
);
CREATE TABLE sales_lines (
  line_id text PRIMARY KEY,
  invoice_id text NOT NULL,
  invoice_date date NOT NULL,
  customer_id text NOT NULL,
  product_id text NOT NULL,
  region text NOT NULL,
  segment text NOT NULL,
  acquisition_channel text NOT NULL,
  qty integer NOT NULL,
  unit_price numeric(12,2) NOT NULL,
  discount_pct numeric(6,4) NOT NULL,
  net_revenue numeric(14,2) NOT NULL,
  cost numeric(14,2) NOT NULL,
  gross_margin numeric(14,2) NOT NULL
);
-- Load the provided CSVs with your preferred local PostgreSQL method.
-- Preserve raw evidence and validate control_totals.json before analysis.
