C2-09 CAPSTONE DATA PACKAGE - INTERNAL QA
Company: Meridian Commerce & Services (synthetic)

Executive question:
Tell us where growth is healthy, where it is fragile, and what we should do next quarter.

Files:
- sales_lines.csv: transaction fact, one row per invoice line
- customers.csv: customer dimension candidate
- products.csv: product dimension candidate
- marketing_spend.csv: month-region-channel marketing fact
- regional_targets.csv: month-region target fact
- customer_health.json: customer-month snapshot fact
- support_tickets.csv: ticket fact with two deliberate quality traps
- source_contracts.json: grain/source role/known traps
- control_totals.json: independent raw controls
- schema_and_seed.sql: optional PostgreSQL-style schema

Important:
1. Do NOT flatten all facts into one giant table.
2. State grain before joining.
3. Preserve raw source copies.
4. One support ticket is duplicated exactly; one ticket has blank priority.
5. West marketing spend is intentionally high; West/Mid-Market health degrades later.
6. These patterns are evidence for investigation, not a prewritten causal conclusion.
7. A solved PBIX, SQL solution, Python solution, final executive answer, or Gate answer is intentionally NOT supplied.

Raw control:
sales rows = 576
net revenue = 1923183.00
gross margin = 1054933.00
marketing rows = 216
support raw rows = 271 / unique ticket ids = 270
